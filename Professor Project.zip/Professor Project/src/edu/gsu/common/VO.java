package edu.gsu.common;

public class VO {
	
	private Customer customer;
	

}
