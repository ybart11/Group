package edu.gsu.common;

public class Action {
	
	public static final String LOGIN = "login";
	public static final String GET_FLIGHTS = "getFlights";
}
