package edu.gsu.excpetions;

public class LoginException extends Exception{
	
	public LoginException(String s) {
		
		super(s);
	}

}
